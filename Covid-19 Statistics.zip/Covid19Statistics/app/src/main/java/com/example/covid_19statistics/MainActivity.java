package com.example.covid_19statistics;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    //general declaration
    TextView currentLocationTextView;
    TextView currentConfirmedTextView;
    TextView currentDeathTextView;
    TextView currentRecoveredTextView;
    Spinner spinner;

    //for location. from youtube tutorial
    Double latitude = 0.0;
    Double longitude = 0.0;
    static String TAG = "MainActivity";
    Location gps_loc = null, network_loc = null, final_loc = null;

    //get prompt user for permission for location. from youtube tutorial
    private static final int REQUEST_LOCATION_PERMISSIONS = 0;

    //search JSON. From youtube tutorial
    private RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //general
        currentLocationTextView = findViewById(R.id.currentLocationTextView);
        currentConfirmedTextView = findViewById(R.id.currentConfirmedTextView);
        currentDeathTextView = findViewById(R.id.currentDeathTextView);
        currentRecoveredTextView = findViewById(R.id.currentRecoveredTextView);
        spinner = findViewById(R.id.spinner);

        //permissions. from youtube tutorial
        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(MainActivity.this, "You have already granted this permission!",
                    Toast.LENGTH_SHORT).show();
        } else {
            requestLocationPermission();
        }

        //search JSON. From youtube tutorial
        mQueue = Volley.newRequestQueue(this);

        jsonParseSpinner();
        jsonParse();

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String text = adapterView.getItemAtPosition(i).toString();
                currentLocationTextView.setText(text);
                jsonParse();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    //code to prompt dialog regarding about permissions. from youtube tutorial
    private void requestLocationPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.ACCESS_FINE_LOCATION)) {

            new AlertDialog.Builder(this)
                    .setTitle("Permission needed")
                    .setMessage("This application requires location permission to provide you with the most accurate data efficiently")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSIONS);
                        }
                    })
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();

        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSIONS);
        }
    }

    //code to handle system dialog regarding about permissions. from youtube tutorial
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_LOCATION_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission GRANTED", Toast.LENGTH_SHORT).show();
                jsonParseSpinner();
                jsonParse();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //code to find location. from YouTube tutorial
    public void findLocation() {
        currentLocationTextView = findViewById(R.id.currentLocationTextView);

        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (
                ActivityCompat.checkSelfPermission(
                        this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                        ActivityCompat.checkSelfPermission(
                                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                        ActivityCompat.checkSelfPermission(
                                this, Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "necessary permissions not granted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "necessary permissions granted", Toast.LENGTH_SHORT).show();
        }

        try {
            gps_loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            network_loc = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (gps_loc != null) {
            final_loc = gps_loc;
            latitude = final_loc.getLatitude();
            longitude = final_loc.getLongitude();
        } else if (network_loc != null) {
            final_loc = network_loc;
            latitude = final_loc.getLatitude();
            longitude = final_loc.getLongitude();
        } else {
            latitude = 0.0;
            longitude = 0.0;
        }

        try {
            Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses != null && addresses.size() > 0) {
                String country = addresses.get(0).getCountryName();
                currentLocationTextView.setText(country);
                spinner.setSelection(getIndex(spinner, country));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private int getIndex(Spinner spinner, String myString){

        int index = 0;

        for (int i=0;i<spinner.getCount();i++){
            if (spinner.getItemAtPosition(i).equals(myString)){
                index = i;
            }
        }
        return index;
    }

    //search JSON. From youtube tutorial
    private void jsonParseSpinner() {

        String url = "https://api.covid19api.com/summary";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                ArrayList<String> stringArrayList = new ArrayList<String>();
                try {
                    JSONArray jsonArray = response.getJSONArray("Countries");

                    for (int g = 0; g < jsonArray.length(); g++) {
                        JSONObject countries = jsonArray.getJSONObject(g);

                        String name = countries.getString("Country");

                        stringArrayList.add(name);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    currentConfirmedTextView.setText("error 4");
                }
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(getApplicationContext(),  android.R.layout.simple_spinner_dropdown_item, stringArrayList);
                adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);

                spinner.setAdapter(adapter);

                findLocation();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                currentConfirmedTextView.setText("error 5");
            }
        });
        mQueue.add(request);

    }

    //search JSON. From youtube tutorial
    private void jsonParse() {

        String url = "https://api.covid19api.com/summary";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                String  fullText = currentLocationTextView.getText().toString();

                Log.d(TAG, "fullText" + fullText);
                try {
                    JSONArray jsonArray = response.getJSONArray("Countries");
                    Log.d(TAG, "loop number " + String.valueOf(jsonArray.length()));
                    for (int g = 0; g < jsonArray.length(); g++) {
                        JSONObject countries = jsonArray.getJSONObject(g);

                        int totalConfirmed = countries.getInt("TotalConfirmed");
                        int totalDeaths = countries.getInt("TotalDeaths");
                        int totalRecovered = countries.getInt("TotalRecovered");
                        String name = countries.getString("Country");

                        Log.d(TAG, "total confirmed - " + totalConfirmed);
                        Log.d(TAG, "name - " + name);

                        if (fullText.equalsIgnoreCase(name)) {
                            currentConfirmedTextView.setText("" + totalConfirmed);
                            currentDeathTextView.setText(""+totalDeaths);
                            currentRecoveredTextView.setText(""+totalRecovered);
                            break;
                        }

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    currentConfirmedTextView.setText("error 2");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                currentConfirmedTextView.setText("error 3");
            }
        });
        mQueue.add(request);
    }
}
